# web3py-block-timestamp
This is a python fork of https://github.com/monosux/ethereum-block-by-date for web3py. It helps converts between a blockchain block and a timestamp. This turns out to be a very common requirement when building web3 applications. it arose from my own requirement itself. 
